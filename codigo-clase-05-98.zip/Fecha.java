class Fecha {

	public Fecha(){
		
	}
	
	public Fecha(int dia, int mes, int a�o){
		
	}
	
	public Fecha(Fecha fecha){
		
	}
	
	public Fecha(int timeStamp){
		
	}
	
	public Fecha(String fecha){
		
	}
	
	public Fecha clone(){
		return null;
	}
	
	public char diaSemana(){
		return ' ';
	}

	public boolean igual(Fecha fecha){
		return false;
	}

	public boolean festivo(){
		return false;
	}

	public int diferencia(Fecha fecha){
		return 0;
	}

	public void mostrar(){
		
	}

	public String toStringCAS(){
		return null;
	}

	public String toStringUSA(){
		return null;
	}

	public String toString(int formato){
		return null;
	}
	
	public void set(Fecha fecha){
	}

	public int getDia(){
		return 0;
	}

	public int getMes(){
		return 0;
	}
	
	public int getA�o(){
		return 0;
	}
	
	public char estacion(){
		return ' ';
	}

	public int numeroSemana(){
		return 0;
	}

	public void incrementar(int dias){
		
	}

	public boolean checkBisiesto(){
		return false;
	}

	public Fecha fechaActual(){
		return null;
	}

	public static void main(String[] arg){
		int longitud = "caracteres".length();
		String cadena = "caracteres";
		boolean falso = cadena == "caracteres";
		System.out.println(falso);
		
		
		
		String ejemplo = " " + (1 + 2) + 3;
		
		
		ejemplo.length();
		"�klajsfdasdfkj".length();
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
}
